#ifndef _SIPCORE
#define _SIPCORE
#include <pjlib-util.h>
#include <pjmedia.h>
#include <pjsip.h>
#include <pjsip_ua.h>
#include <pjsip/sip_auth.h>
#include <pjlib.h>

class SipCore
{
public:
    SipCore();
    ~SipCore();

    // 初始化传输层接口 pjsip传输层支持udp tcp tls
    pj_status_t init_transport_layer(int sipPort);

    bool initSip(int sipPort);
    pjsip_endpoint*get_pjsip_endpoint(){
        return _endpoint;
    }
private:
    pj_caching_pool _caching_pool;
    pjsip_endpoint *_endpoint;
    pj_pool_t* m_pool;
};

#endif