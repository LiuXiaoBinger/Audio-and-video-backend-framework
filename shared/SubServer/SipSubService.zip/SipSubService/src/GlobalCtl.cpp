#include "GlobalCtl.h"

 GlobalCtl *GlobalCtl::m_instance = nullptr;
 pthread_mutex_t GlobalCtl::globalLock = PTHREAD_MUTEX_INITIALIZER;
 bool GlobalCtl::_gStopPool=false;
 GlobalCtl::~GlobalCtl()
 {
 }
 GlobalCtl *GlobalCtl::instance()
 {
     if (!m_instance)
     {
         m_instance = new GlobalCtl();
     }
     return m_instance;
}

bool GlobalCtl::init(void *param)
{
    _gConfig=(SipLocalConfig*)param;
    if(!_gConfig)
    {
        return false;

    }
    //初始化上级服务器列表信息
    SupDomainInfo info;
    auto iter = _gConfig->upNodeInfoList.begin();
    for(;iter != _gConfig->upNodeInfoList.end();++iter)
    {
        info.sipId = iter->id;
        info.addrIp = iter->ip;
        info.sipPort = iter->port;
        info.protocal = iter->poto;
        info.expires = iter->expires;
        if(iter->auth)
        {
            info.isAuth = (iter->auth = 1)?true:false;
            info.usr = iter->usr;
            info.pwd = iter->pwd;
            info.realm = iter->realm;
        }
        _supDomainInfoList.push_back(info);
    }
     if(!gThPool)
    {
        gThPool =  new ThreadPool();
        gThPool->createThreadPool(10);
    }
    if(!gSipServer)
    {
        gSipServer = new SipCore();
    }
    gSipServer->initSip(_gConfig->sipPort());
    return true;
}
